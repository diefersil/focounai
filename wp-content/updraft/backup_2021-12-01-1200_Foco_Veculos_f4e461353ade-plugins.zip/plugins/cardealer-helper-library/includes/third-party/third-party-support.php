<?php
/**
 * Third Party Support
 *
 * @author  TeamWP @Potenza Global Solutions
 * @package car-dealer-helper/third-party-support
 * @version 1.9.0
 */

require_once trailingslashit( CDHL_PATH ) . 'includes/third-party/cf7.php';
require_once trailingslashit( CDHL_PATH ) . 'includes/third-party/cf7-custom-validation.php';
require_once trailingslashit( CDHL_PATH ) . 'includes/third-party/cf7-data-options.php';
