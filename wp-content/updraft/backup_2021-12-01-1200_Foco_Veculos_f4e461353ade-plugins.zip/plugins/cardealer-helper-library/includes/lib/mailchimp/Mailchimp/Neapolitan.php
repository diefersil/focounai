<?php
/**
 * Neapolitan
 *
 * @author  TeamWP @Potenza Global Solutions
 * @package car-dealer-helper
 */
class Mailchimp_Neapolitan {
	/**
	 * Mailchimp Neapolitan
	 *
	 * @param Mailchimp $master .
	 */
	public function __construct( Mailchimp $master ) {
		$this->master = $master;
	}

}


