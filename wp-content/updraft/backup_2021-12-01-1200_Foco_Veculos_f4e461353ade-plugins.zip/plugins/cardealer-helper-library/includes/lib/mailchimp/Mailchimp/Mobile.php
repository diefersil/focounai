<?php
/**
 * Mobile
 *
 * @author  TeamWP @Potenza Global Solutions
 * @package car-dealer-helper
 */
class Mailchimp_Mobile {
	/**
	 * Mailchimp mobile
	 *
	 * @param Mailchimp $master .
	 */
	public function __construct( Mailchimp $master ) {
		$this->master = $master;
	}

}
