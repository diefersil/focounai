<?php
get_template_part( 'template-parts/cars/single-car/tabs/tabs' );
