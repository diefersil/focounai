<?php
cardealer_add_vehicale_to_cart( get_the_ID() );
