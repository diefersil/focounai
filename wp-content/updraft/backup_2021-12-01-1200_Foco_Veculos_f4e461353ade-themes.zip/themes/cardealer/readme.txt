Car Dealer is a multi purpose [WordPress](http://www.wordpress.org "WordPress") theme powered with Visual composer with lot of layout/design possibilities.

## Features ##

* Powered with Visual Composer
* Easy to use theme settings
* One click sample data import
* Much more:  https://themeforest.net/item/car-dealer-automotive-responsive-wordpress-theme/20213334#item-description__main-features-overview

## Envato Bundle Plugins Policy ##
All premium plugins like Visual Composer included in the themes are full featured and work properly right out of the box. New versions will be included in the upcoming updates after compatibility tests. For more information 

please read Envato Bundled Plugins policy: https://help.market.envato.com/hc/en-us/articles/213762463-Bundled-Plugins